# LiquidAss Background Pipeline + Plugin Group Optics

## 液态Dock 1.0 — fixed user-selected preset

- Final display name and Description are both `液态Dock`; Debian version is exactly `1.0`. The existing package identifier is retained for same-package replacement.
- Removed the settings bundle, PreferenceLoader entry/dependency and all runtime preference reading/writing, migration and settings observers. The Dock is always enabled when this tweak is loaded; historical saved values do not affect it. No device data is erased by the build.
- Fixed for both appearances: radius 0 (native), surface 0, thickness 28pt, bezel 27pt, IOR 1.9, refraction scale 2.8, blur 0, specular 0.25, saturation 6, innerBlur 0, innerSpread -15, tintOpacity 0, outerBlur 0, opacity 100%, outerOpacity 0, outer offsets 0. Tint and inner colors are #FFFFFF; outer color #000000. Native geometry/density/zoom are preserved.
- The last screenshot's integer percent controls (190 / 280 / 25) are represented by their original renderer units (1.9 / 2.8 / 0.25), not by inflated raw values.
- The real-time BackBoardd/CABackdropLayer pipeline, Dock ownership, shader, CA command ownership and failure fallback are retained. The renderer-ready notification remains for startup ordering; it is not a settings interface.
- Local execution/packaging checks are not on-device visual verification. The build never installs to or restarts a device.

The sections below record historical development versions, not the active 1.0 feature set.

## 1.12 — Dock only, shared profile, stronger clear refraction

- Removed the open-folder hook/build entry, frontend permission, custom filter registration, settings and appearance profiles. Retired registry slots preserve numeric ABI only and carry no folder identifiers.
- One master `enabled` switch and `Dock.Profile` serve both appearances; Dock's effective filter no longer changes for dark mode. Legacy Dock.Light wins over Dock.Dark during migration. Removed-host data is never consumed and is dropped on the next explicit save/reset.
- Migration/default values use thickness 120, scale 3 and a 0.22 narrow glint; blur/tint defaults stay zero. Scale is editable through 6 (600 in the UI). Later canonical user values are not forcibly raised.
- The production shader, CA texture/command lifecycle, native-density sampling and safety fallbacks are retained. Host GPU displacement tests do not establish device visual acceptance. Build/delivery never installs to the phone.

Upstream: winaviation-tweaks/liquidass
Repository: https://github.com/winaviation-tweaks/liquidass
Pinned commit: 9b7c5eb813dabf7ea3afb940767930e128fca775
License: CC BY-NC 4.0, https://creativecommons.org/licenses/by-nc/4.0/
See LICENSE and NOTICES.md. Noncommercial derivative; no upstream endorsement.

## Version 1.11: declared Dock background ownership (device test pending)

Only the Dock host adapter changes. Both native owner classes expose
`backgroundView`; the declaration is typed UIView, not guaranteed to be the
innermost MTMaterialView. The adapter now uses this declared root, validates
only its bounded background subtree, rejects icon/list content, and keeps one
LiquidAss glass sibling above the complete native background and below the
existing foreground. A previous inner glass is removed before root adoption.
Native background changes, disable and window removal restore the owned root;
stable layout and parameter updates reuse the existing glass instance.

No stock shadow view, icons, divider, labels, badge, OpenFolder adapter,
LGLiveBackdropView implementation, Backboardd code, Gaussian fallback or group
shader changed. The four parameter profiles and their display units are kept.
Runtime declaration evidence: MTACS/iOS-17-Runtime-Headers, main tree
`d1d960dfaa4107765dd7fcf891e4967c0930d5fd` (README identifies iOS 17.0.3),
SpringBoardHome SBDockView.h and SBFloatingDockPlatterView.h. Declarations and
host substitutes do NOT prove which layers exist on the user's phone.

The executable production-helper fixture covers regular/floating direct and
wrapped backgrounds, old inner-glass retirement, 100 stable layouts, geometry,
disable/re-enable, native replacement, off-window restoration and foreground
identity. These checks are local evidence only. This is a targeted test build
for an incomplete-background handoff risk, not a claim that the phone's blur
root cause or final clarity has been verified. No device was connected.

## Version 1.10: integer controls and automatic live parameter application

The Settings bundle now uses large number fields and synchronized continuous
sliders. Every displayed scalar is an integer. IOR, refraction scale and specular
opacity use percent units; blur uses tenths of a point. The stored optical values
and the canonical plugin-group shader/schema are unchanged. Dock/OpenFolder and
light/dark remain four independent profiles, with all optical parameters and
color controls retained.

Width and height are no longer editable. Host layout and screen-density sampling
remain authoritative; legacy width/height/capture/zoom overrides are ignored in
the runtime snapshot without rewriting the user's saved file. Changes coalesce
on a serial background writer, persist atomically and notify both processes.
The renderer acknowledges only AFTER reloading its cache; live filter refresh
follows that existing ParametersReloaded notification. No respring, user-space
reboot, host recreation or active 1.7 coverage/Gaussian override is introduced.

Host tests cover integer round trips, four-profile persistence, rapid input,
legacy-layout suppression and real two-process Darwin reload/ack ordering. These
checks and clean package verification do not prove device clarity or stability.
The user's reported blur remains unverified on-device; no phone was connected.

## Version 1.7 (historical; reverted in the active 1.8+ baseline)

The following coverage/Gaussian changes are historical documentation, not the
active renderer. They were reverted after device flicker feedback. The active
baseline uses the unmodified group shader and the 1.6 native sampling policy.

### Historical explicit native Gaussian policy and pixel-space edge coverage

Source-only audit found two independent settings not covered by the shader's
blur=0: native CAFilter inputRadius was unspecified on the normal path, and the
group shader feathered alpha over a fixed 0.8-point inward band. Dock/OpenFolder
now explicitly request native radius 0 on the normal route. The existing guarded
Gaussian-identity fallback retains radius 1; its device state was NOT inspected.
No safety flags, dispatch hooks, input texture or foreground placement change.

The canonical plugin-group shader remains byte-identical. A strict, fail-closed
source adapter changes only alpha coverage: screen derivatives computed before
the outside-fragment branch replace the fixed point-space feather with pixel-space
coverage. Snell/refraction math, texture sampling, optical/color values and shape
geometry are unchanged. Real host GPU tests compare both variants at densities
1–4, assert fewer partially transparent edge pixels, unchanged opaque-region RGB
(at most rounding tolerance), retained displacement and live texture updates.

These are tested source fixes, NOT a confirmed diagnosis of the device's entire
blur chain. No phone was connected, no runtime filter/fallback state was read,
and final device clarity remains unverified. No nearest-neighbor pixelation,
sharpening, added white veil or rebuilt background producer is used.

## Version 1.6: clear sampling without changing working refraction

Dock and OpenFolder now request screen-density background samples instead of
the upstream area-budgeted 0.25–0.75 capture scale. The conversion follows the
existing renderer's scale-times-two contract; a 3x screen requests scale 1.5
and a 2x screen requests scale 1.0. Sampling remains live in the render server;
there is no new screenshot path, CPU capture, frozen frame or refresh throttle.
The group shader, fixed screenshot optics, background placement, registration
and fallback are unchanged. Blur and tint remain zero; no exposure/white veil
is added. This avoids additional capture-resolution softening but cannot
invent sharp details absent from the wallpaper or guarantee device appearance.

## Version 1.5: style-only integration

The complete LiquidAss-derived SpringBoard material lifecycle, Dock/OpenFolder
routes, private-symbol resolver, filter registration, safe-mode logic, CA-owned
source/destination textures, stock fallback and CA command-buffer ownership are
retained from the 1.4 architecture. No screenshot producer, separate readiness
protocol, foreground sampling, new preferences page or new UIKit surface is added.

Only the custom material's optical pass changes: the exact HangLiquidShader.h,
HangLiquidUniforms.h and HangLiquidParameterSchema.h files from the user's plugin
group are used. Core/HDKGroupBackdropStyle.h adapts the EXISTING CA background
texture's pixel dimensions and routed corner radius to the group shader's point
space. The viewport preserves CA destination padding and the pre-existing stock
pass. The upstream shader text is retained byte-for-byte in the combined library,
but the active material pipeline selects hangLiquidVertex/hangLiquidFragment.

Fixed screenshot values were already recorded in Core/HDKDefaults.h and are now
actually consumed by the optical pass: thickness 25, bezel 60, IOR 3, refraction
scale 2, blur 0, specular opacity 0.2, specular saturation 4, inner blur 0,
inner spread -15 and tint opacity 0. Native host geometry remains authoritative;
external shadow/host layout is not rebuilt. The shader and parameter schema are
not rewritten or replaced with a visual approximation.

For Dock and OpenFolder only, the upstream native blur overlay and second
specular decoration defer to the group shader, avoiding stacked gray blur or
double highlights. Other upstream helpers and background placement are unchanged.

## Scope and standalone adaptations

Only Dock and the background of an OPEN folder are enabled. Folder icons, app
icons, labels, badges, notification panels, app UI and keyboard effects are not
installed or transformed. SpringBoard and backboardd filters are iOS 17 only.
Filter, notification and guard-file namespaces are isolated from upstream.
OpenFolder is extracted from Hooks/Folder.x; folder-icon hooks are excluded.
A standalone PreferenceBundle and one directory-based PreferenceLoader entry
ship from 1.8 onward. Settings use the standalone com.hang.liquiddock store;
upstream preference domains remain isolated and are not imported.
Safety guards do not clear another product's files. No device access is added.

UPSTREAM.json records upstream/adapted source hashes. Package receipts additionally
record the group shader, uniform/schema and fixed-preset hashes. Host tests include
real Metal execution at densities 1–4, IOR=1 refraction controls, updated source
pixels, direct group render equivalence and centered CA padding. These do not
validate private rendering or final appearance on a physical iOS device.
